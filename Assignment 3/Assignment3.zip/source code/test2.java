import java.lang.String;

public class test2 {
	public static void main(String[] args)
	{
	   int n;
	   String K;
	   char C;

	   n=123;
	   K = (String)n;
	   System.out.println(K);
	}

}
