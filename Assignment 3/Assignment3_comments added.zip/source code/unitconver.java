/*
  CSC130 Problem #1
  Program: Convert from meters to miles, feet and inches
  Modified Date: Feb 8 2013
  Author: Julie Yu(JUNGHYUN YU)
*/ 

public class 

